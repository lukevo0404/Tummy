
<div class="header_area clearfix" id="back-top-here">

	<nav class="navbar navbar-default clearfix">
	  <div class="container">
		<div class="navbar-header clearfix">
		  <button type="button" class="navbar-toggle navbar-toggle-my" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>                        
		  </button>
		  <a class="navbar-brand logo" href="./"><img src="img/logo.png" style=""></a>
		</div>
		<div class="navbar-collapse collapse clearfix " id="myNavbar">
		  <ul class="nav navbar-nav navbar-right">
			<li><a href="#back-top-here">Home</a></li>
			<li><a href="#about">About</a></li>
			<li><a href="#token_model">Tummy's Token Model</a></li>
			<li><a href="#roadmap">Roadmap</a></li>
			<li><a href="">Whitepaper</a></li>
			<li><a href="">Buy now</a></li>
		  </ul>
		</div>
	  </div>
	</nav>
	<div style="clear:both"></div>
</div>

	<div style="clear:both"></div>
    <!--Preloader start-->

			

  

  
  
  
 