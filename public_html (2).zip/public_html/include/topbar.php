		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="cache-control" content="no-cache" />



        <link rel="shortcut icon" href="img/logo_main.png" type="image/x-icon">  
		<meta http-equiv="Pragma" content="no-cache" />
        <title>Piglets</title>
        <!--Favicon add-->
    	<link rel="shortcut icon" type="image/png" href="">
        <!--bootstrap Css-->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        
        <!--font-awesome Css-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
        <!--owl.carousel Css-->
		<link href="css/owl.carousel.css" rel="stylesheet">
        <!--Slick Nav Css-->
        <!--Animate Css-->
        <link href="css/animate.css" rel="stylesheet">
        <!--bootstrap Css-->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!--Style Css-->
        <link href="css/style.css" rel="stylesheet">
        <!--Responsive Css-->
        <link href="css/responsive.css" rel="stylesheet">
        
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,500i,700,900&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,700i,800&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,400;0,500;0,700;1,700&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.gstatic.com">


    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Changa:wght@200;400;500;600;700;800&display=swap" rel="stylesheet">


  <link href="banner_working/normalize.css" rel="stylesheet" type="text/css">
  <link href="banner_working/components.css" rel="stylesheet" type="text/css">
  <link href="banner_working/shibamoonbsc.css" rel="stylesheet" type="text/css">
  
