<!DOCTYPE html>
<!-- saved from url=(0021)https://shibamoon.co/ -->
<html data-wf-page="6099e35e1266ca1f33ecd150" data-wf-site="6099e35e1266ca357cecd14f" class="w-mod-js w-mod-ix wf-dmsans-n7-active wf-dmsans-n5-active wf-dmsans-n4-active wf-dmsans-i4-active wf-dmsans-i5-active wf-dmsans-i7-active wf-active"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">c
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="cache-control" content="no-cache" />

  <link rel="shortcut icon" href="img/logo_main.png" type="image/x-icon">  
        <title>Tummy Coin</title>
        <!--Favicon add-->
      <link rel="shortcut icon" type="image/png" href="">
        <!--bootstrap Css-->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        
        <!--font-awesome Css-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
        <!--owl.carousel Css-->
    <link href="css/owl.carousel.css" rel="stylesheet">
        <!--Slick Nav Css-->
        <!--Animate Css-->
  <link href="animation_move/shi.css" rel="stylesheet" type="text/css">
        <link href="css/animate.css" rel="stylesheet">
        <!--bootstrap Css-->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!--Style Css-->
        <link href="css/style.css" rel="stylesheet">
        <!--Responsive Css-->
        <link href="css/responsive.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700;800;900&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,500i,700,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,700i,800&display=swap" rel="stylesheet">

</head>
<body class="body">
<?php include 'include/header.php';?>
<section class="slider padding_section"  id="intro">

    <div class="section_demo">
  <canvas id="demo"></canvas>
</div>
    <div class="container clearfix intro">

  <div id="home" class="section-hero">
    <div class="content">
      <div data-w-id="bfdef6b2-2e26-0bbb-6944-284fe24ab051" class="block-hero-img"><img src="img/logo_main.png" loading="lazy"  alt="" class="app-screen---hero-1" style="will-change: transform; transform: translate3d(0px, 12.0066px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg, 0deg); transform-style: preserve-3d;">
        <div class="block-circle---hero-1"><img src="img/shi/10.png" loading="lazy" alt="" class="image-circle---4"><img src="shi/10.png" loading="lazy" alt="" class="image-circle---5"><img src="shi/4.png" loading="lazy" alt="" class="image-circle---7 _10"><img src="shi/13.png" loading="lazy" alt="" class="image-circle---8"></div>
        <div class="block-circle---hero-2"><img src="shi/12.png" loading="lazy" alt="" class="image-circle---1 _2"><img src="shi/6.png" loading="lazy" alt="" class="image-circle---3" ></div>
      </div>
    </div>
  </div>
  <div class="slider_inner col-sm-12 ">
  <h2 class="wow  fadeInUp" data-wow-duration="400ms" data-wow-delay="200ms">Tummy's goal is simple. 
1000x the price & fill the tummies of those in need.</h2>
      <div class="view-buy other_btn wow  fadeIn" data-wow-duration="600ms" data-wow-delay="300ms">
        <a href="" target="_blank"><span>Whitepaper</span></a>
      </div>
      <div class="slider_social wow  fadeIn" data-wow-duration="800ms" data-wow-delay="400ms">
      <a href="">
            <i class="fa fa-facebook"></i>
    </a><a href="">
            <i class="fa fa-instagram"></i>
    </a><a href="">
            <i class="fa fa-telegram"></i>
    </a><a href="">
            <i class="fa fa-twitter"></i>
    </a>
  </div>
      </div>
      <!--<div class="slider_inner row">
        <div class="col-sm-7">
          <div class="slider_contact">
            <div class="owl-carousel owl-theme">
        <div class="item">
            
            <div class="view-buy wow  fadeInUp"   data-wow-duration="600ms" data-wow-delay="1000ms">
              <a href=""><span> Click here</span></a>
            </div>
          </div>
        </div>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="slider_image wow  zoomIn" data-wow-duration="600ms" data-wow-delay="200ms">
            <img src="img/banner1.jpg" class="img-responsive">
          </div>
        </div>
      </div>-->
    </div>
  </section>
  <script src="animation_move/jquery-3.5.1.min.dc5e7f18c8.js" type="text/javascript" crossorigin="anonymous"></script>
  <script src="animation_move/shibamoonbsc.js" type="text/javascript"></script>
  <!-- ShibaMoon, from Shiba lovers, to Shiba lovers. -->

  <!--<section class="about about_single padding_section" id="about">
    <div class="container">
<div class="about_contact wow  fadeInUp text-center" data-wow-duration="800ms" data-wow-delay="200ms">
            <h2><b><span>Pricing Stats</span></b></h2>
          </div>
             <div class="fee_inner ">
          <div class="about_contact  fee_content text-center wow ">
            <div class="main_cols row">
              <div class="col-md-4 col-sm-4">
                            <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="200ms">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/cl/2.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                  <h4>PASSIVE INCOME</h4>
                                  <p>Earn passive MNRY & BNB by holding MNRY tokens</p>

                              </div>
                            </div>
                        </div>
              <div class="col-md-4 col-sm-4">
                            <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="400ms">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/cl/2.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                  <h4>NO-LOSS LOTTERY</h4>
                                  <p>Stake $MNRY to be eligible to win weekly Lottery prizes</p>

                              </div>
                            </div>
                        </div>
              <div class="col-md-4 col-sm-4">
                            <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="400ms">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/cl/2.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                  <h4>NO-LOSS LOTTERY</h4>
                                  <p>Stake $MNRY to be eligible to win weekly Lottery prizes</p>

                              </div>
                            </div>
                        </div>
                        <div style="clear: both;"></div>
                        
            </div>
          </div>
        </div>
    </div>
  </section>-->
<section class="fee_section padding_section wow fadeIn" id="token_model" data-wow-duration="200ms" data-wow-delay="200ms" style="visibility: visible; animation-duration: 200ms; animation-delay: 200ms; animation-name: fadeIn;">
    <div class="container">

      <div class="fee_inner ">
          <div class="about_contact  fee_content text-center wow  animated" style="visibility: visible;">
            
            <div class="main_title">
              <h2>TUMMY'S TOKEN MODEL</h2>
            </div>
            <div class="main_cols row">
              <div class="col-md-3 col-sm-3">
                            <div class="single_work wow  zoomIn" data-wow-duration="1000" data-wow-delay="200ms" style="height: 309px; visibility: visible; animation-delay: 200ms; animation-name: zoomIn;">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/cl/1.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                  <h4>FULL TRANSPARENCY</h4>
                                  <p>100% transparent community run project</p>

                              </div>
                            </div>
                        </div>
              <div class="col-md-3 col-sm-3">
                            <div class="single_work wow  zoomIn" data-wow-duration="1000" data-wow-delay="400ms" style="height: 309px; visibility: visible; animation-delay: 400ms; animation-name: zoomIn;">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/cl/2.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                  <h4>Token Supply</h4>
                                  <p>1,000,000,000,000 $TUMMY</p>

                              </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="single_work  wow  zoomIn" data-wow-duration="1000" data-wow-delay="600ms" style="height: 309px; visibility: visible; animation-delay: 600ms; animation-name: zoomIn;">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/cl/3.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                   <h4>LIQUIDITY LOCKED</h4>
                                  

                                  <p>Liquidity will be locked for 10 years</p>
                              </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="single_work  wow  zoomIn" data-wow-duration="1000" data-wow-delay="600ms" style="height: 309px; visibility: visible; animation-delay: 600ms; animation-name: zoomIn;">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/icon4.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                   <h4>OWNERSHIP RENOUNCED</h4>
                                  

                                  <p>Ownership will be renounced after launch</p>
                              </div>
                            </div>
                        </div>
                        <div style="clear: both;"></div>
                        
            </div>
          </div>
        </div>
    </div>
  </section>
  <section class="about about_single padding_section" id="about">
    <div class="container">
      <div class="about_inner row align-items-center">
        <div class="col-sm-7">
          <div class="about_contact wow  fadeInUp text-left"   data-wow-duration="800ms" data-wow-delay="200ms" style="">
            <h2><b><span>Why Tummy Coin?</span></b></h2>
            <p>Our initial idea was to create a coin that can possible go up to 1000x and financial freedom for the holders. Guarantee no rug pull as we want the coin to be highly sought-after in the market, high value, full transparency, and can sustain itself based on the community.</p>
            <p>Our team went on and did some extensive research, and we came out with an idea which is; we want to create a charity based coin. And our concept is “ Possible “. It mixed with financial freedom and kindness, and this is what we want to define Tummy coin. While making money, we do good deeds too, which is to feed those who are in needs and also contribute back to the community. And, that’s the goal for everyone in the community. There is a saying “Be kind whenever possible; it is always possible”. It’s meaningless while having everything without doing good deeds. Tummy coin is making anything possible to you.</p>
          </div>
        </div>

        <div class="col-sm-5">
            <div class="about_image_main wow  zoomIn" data-wow-duration="600ms" data-wow-delay="200ms">
            <img src="img/tummy-coin-portal.png" alt="aboutimg4" class="img-responsive">
            
          </div>
        </div>
      </div>
      <div style="clear: both;" ></div>

             
    </div>
  </section>
  <section class="tokenomics_section padding_section" id="tokenomics">
    <div class="container">
      <div class="row clearfix">
        <div class="col-sm-12 main_content_test">
          
          <div class="about_contact wow  fadeInUp"   data-wow-duration="800ms" data-wow-delay="200ms" style="">
            <h2>TUMMY'S TOKENOMICS & FEATURES</h2>
            
            <p>Every Tummy Coin transaction (purchased or sold) has an automatic 10% transaction tax, which is then divided 3% back to Holders, 3% deposited for Charity Funds, 2% back to Locked LP, and 2% burnt.</p>
          </div>

        </div>
      </div>
    </div>
  </section>

      <div class="test_slider">
        <div class="inner_test">
        <div class="container">
        <div class="owl-carousel owl-theme">
          <div class="item">

                            <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="400ms">
                                <div class="fee_bg_content">

                              <div class="secure_ing">
                                <img src="img/a1a.png" class="img-responsive" >
                              </div>
                                  <h4>3% to Charity</h4>
                                  <p></p>

                              </div>
                            </div>
                          </div>

          <div class="item">
                            <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="400ms">
                                <div class="fee_bg_content">

                              <div class="secure_ing">
                                <img src="img/cl/3.png" class="img-responsive" >
                              </div>
                                  <h4>3% to Holders</h4>
                                  <p></p>

                              </div>
                            </div>
                          </div>

          <div class="item">
                            <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="400ms">
                                <div class="fee_bg_content">

                              <div class="secure_ing">
                                <img src="img/a3.png" class="img-responsive" >
                              </div>
                                  <h4>2% to Auto LP</h4>
                                  <p></p>

                              </div>
                            </div>
                          </div>
          <div class="item">
                            <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="400ms">
                                <div class="fee_bg_content">

                              <div class="secure_ing">
                                <img src="img/fire.png" class="img-responsive" >
                              </div>
                                  <h4>2% Burnt</h4>
                                  <p></p>

                              </div>
                            </div>
                          </div>
          </div>
        </div>
      </div>
      </div>
      </div>
  <section class="mission_vision padding_section">
    <div class="container">
      <div class="about_inner row">

        <div class="col-sm-6">
          <div class="about_contact wow  fadeInUp"   data-wow-duration="800ms" data-wow-delay="200ms" style="">
            <h2>EVERY <b><span>TUMMY COIN'S</span></b> TRANSACTION HELPS THOSE IN NEED.</h2>
            <p>We are committed to donating up to $333,333 each month to charity through the 3% collection of the coin tax.</p>
            <p>To help create a win/win situation for both the charity and Tummy Coin holders, everything collected over the weekly $333,333 donation will be used to buy back Tummy Coins and burn them to reduce supply and increase value.</p>
            <p>Join us on our 1000x mission to solve world hunger!</p>
            

          </div>
        </div>

        <div class="col-sm-5">
          <div class="ch about_image_main wow  zoomIn"   data-wow-duration="600ms" data-wow-delay="200ms"><img src="img/tummy-coin-food-charity.png" alt="place your img" class="img-responsive wow FadeIn" data-wow-delay="0.2s">
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--<section class="fee_section padding_section wow fadeIn" id="token_model" data-wow-duration="200ms" data-wow-delay="200ms">
    <div class="container">

      <div class="fee_inner ">
          <div class="about_contact  fee_content text-center wow ">
            
            <div class="main_title">
              <h2>Tummy Token Model</h2>
            </div>
            <div class="main_cols row">
              <div class="col-md-3 col-sm-3">
                            <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="200ms">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/icon1.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                  <h4>Pre-Sale</h4>
                                  <p></p>

                              </div>
                            </div>
                        </div>
              <div class="col-md-3 col-sm-3">
                            <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="400ms">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/icon2.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                  <h4>Presale vesting</h4>
                                  <p>50% on launch. 25% after 2 weeks. 25% after 4 weeks.</p>

                              </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="single_work  wow  zoomIn"   data-wow-duration="1000" data-wow-delay="600ms">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/icon3.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                   <h4>Initial Liquidity</h4>
                                  

                                  <p>40.000.000 Tummy</p>
                              </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="single_work  wow  zoomIn"   data-wow-duration="1000" data-wow-delay="600ms">
                                <div class="fee_bg fee_bg_img">
                                    <img src="img/icon1.png" alt="place your img">
                                </div>
                                <div class="fee_bg_content">
                                   <h4>Marketing</h4>
                                  

                                  <p>5.000.000 Tummy</p>
                              </div>
                            </div>
                        </div>
                        <div style="clear: both;"></div>
                        
            </div>
          </div>
        </div>
    </div>
  </section>-->

  <!--<section class="stats about about_single padding_section" id="about">
    <div class="container">
      <div class="about_inner">
        <div class="col-sm-12">
          <div class="about_contact wow  fadeInUp text-center"   data-wow-duration="800ms" data-wow-delay="200ms" style="">
            <h2><b><span>Pricing Stats</span></b></h2>
          </div>
        </div>

      <div style="clear: both;" ></div>

             <div class="fee_inner ">
          <div class="about_contact  fee_content text-center wow ">
            <div class="main_cols row">
              <div class="col-md-4 col-sm-4">
                <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="200ms">
                    <div class="fee_bg fee_bg_img">
                        <img src="img/cl/1.png" alt="place your img">
                    </div>
                    <div class="fee_bg_content">
                      <h4>2,303,293</h4>
                      <p>Holders</p>

                  </div>
                </div>
            </div>
              <div class="col-md-4 col-sm-4">
                <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="200ms">
                    <div class="fee_bg fee_bg_img">
                        <img src="img/cl/2.png" alt="place your img">
                    </div>
                    <div class="fee_bg_content">
                      <h4>2,303,293</h4>
                      <p>Holders</p>

                  </div>
                </div>
            </div>

              <div class="col-md-4 col-sm-4">
                <div class="single_work wow  zoomIn"   data-wow-duration="1000" data-wow-delay="200ms">
                    <div class="fee_bg fee_bg_img">
                        <img src="img/cl/3.png" alt="place your img">
                    </div>
                    <div class="fee_bg_content">
                      <h4>2,303,293</h4>
                      <p>Holders</p>

                  </div>
                </div>
            </div>
                        <div style="clear: both;"></div>
                        
            </div>
          </div>
        </div>
    </div>
  </section>-->
  <!--<section class="how_work work_section padding_section ripple" id="how_to_buy">
    <div class="container">

      <div class="work_inner choose_patten_bg clearfix">
            <div class="about_contact  work_content clearfix text-center wow  fadeInUp"   data-wow-duration="800ms" data-wow-delay="200ms">

          <div class="col-sm-12">
              <div class="main_title">
<h3><b>Find Out How to:</b></h3>
                <h2>Tummy Coin</h2>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                <p class="text-info"><strong><span class="badge bg-success text-dark">1</span></strong> Set Slippage 11-13%</p>
                <p class="text-info"><strong><span class="badge bg-success text-dark">1</span></strong> Set Slippage 11-13%</p> 
            <div class="view-buy other_btn  wow  fadeInUp"   data-wow-duration="600ms" data-wow-delay="1000ms">
              <a href=""><span>Buy Tummy</span></a>
            </div>
            <br>

              </div>
            </div>
          <!--<div class="buy_image_center">
          <div class="  work_content text-center" style="">
            
            <div class="main_cols row">
              <div class=" wow  fadeIn"   data-wow-duration="1000" data-wow-delay="500ms">
                                  <img src="img/pancakeTrade-908x1024.png" class="img-responsive" />
                          </div>
            </div>
          </div>
        </div>
          </div>
    </div>
  </div>

  </section>-->
  
  <section class="roadmap_section padding_section" id="roadmap">
    <div class="container">

      <div class="roadmap_inner choose_patten_bg">
        <div class="about_contact  work_content text-center" style="">
          <div class="main_title">
            <h2>Roadmap</h2>
            <p>Our roadmap is more of a to-do list. The dates are rough and allows us the entire month to complete the task.</p>
          </div>
          <div class="row clearfix image_set">
          <div class="main_cols class_relative col-sm-6">
            <div class="border_line"></div>
              <div class="cols text-center clearfix">
                <div class="icon_title_left clearfix wow  fadeInUp"   data-wow-duration="1000" data-wow-delay="200ms">

                  <div class="feature-icon">
                    <i class="fa fa-diamond"></i>

                  </div>
                </div>
                <div class="content_title_right wow  fadeInDown"   data-wow-duration="1000" data-wow-delay="400ms">
                  <div class="feature-content">
                    <h5>APRIL/ MAY 2021</h5>
                    <ul>
                      <li>Conceptualization & Ideation of Tummy</li>
                      <li>Build Team of Developers & Social Media Marketers</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="cols text-center clearfix">
                <div class="icon_title_left clearfix wow  fadeInUp"   data-wow-duration="1000" data-wow-delay="200ms">

                  <div class="feature-icon">
                    <i class="fa fa-diamond"></i>

                  </div>
                </div>
                <div class="content_title_right wow  fadeInDown"   data-wow-duration="1000" data-wow-delay="400ms">
                  <div class="feature-content">
                    <h5>JUNE/ JULY 2021</h5>
                    <ul>
                      <li> Pre sale of Tummy</li>
<li>Launch of Website, Telegram, Twitter, Instagram, TikTok</li>
<li>Whitepaper Release</li>
<li>Official launch of Tummy</li>
<li>Liquididty Protocol Locked for 10 years</li>
<li>Renounce Ownership</li>
<li>1,000 Holders</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="cols text-center clearfix">
                <div class="icon_title_left clearfix wow  fadeInUp"   data-wow-duration="1000" data-wow-delay="200ms">

                  <div class="feature-icon">
                    <i class="fa fa-diamond"></i>

                  </div>
                </div>
                <div class="content_title_right wow  fadeInDown"   data-wow-duration="1000" data-wow-delay="400ms">
                  <div class="feature-content">
                    <h5>AUGUST 2021</h5>
                    <ul>
                      <li> Initial Marketing Campaign</li>
<li> Complete Donation to Binance</li>
<li> Application to CoinGecko</li>
<li> Application to CoinMarketCap</li>
<li> 2,500 Holders</li>
                    </ul>
                  </div>
                </div>
              </div>

              </div>

          </div>
          </div>
          <!--<div class="col-sm-6">
            <div class="solution_image">
              <img src="img/solution.png" class="img-responsive">
            </div>
          </div>-->
        </div>
      </div>
    </div>
  </section>
<section class="faq_section padding_section">
    <div class="container">
        <div class="row clearfix">
        <div class="col-sm-12">

      <div class="about_contact  work_content text-center" style="">
          <div class="title_here">

            <h2>FAQ</h2>
          </div>
        </div>
        <div class="faq_box clearfix row">
        <div class="col-sm-6">
<div class="panel-group" id="accordion">
  <div class="panel panel-default wow  fadeIn" data-wow-duration="1000" data-wow-delay="200ms" >
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapse1" aria-expanded="false">What are the tokenomics? <div class="plus_minus"><i class="fa fa-plus"></i><i class="fa fa-minus"></i></div></a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse" aria-expanded="false" >
      <div class="panel-body">- 15% Pre Sale<br>
- 50% of the supply will be burnt after launch<br>
- 30% Fair Launch (Locked LP For 10 Years)<br>
- 5% Airdrop & Marketing </div>
    </div>
  </div>
  <div class="panel panel-default wow  fadeIn" data-wow-duration="1000" data-wow-delay="400ms">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapse2" aria-expanded="false">Why Invest in $TUMMY? <div class="plus_minus"><i class="fa fa-plus"></i><i class="fa fa-minus"></i></div></a>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse" aria-expanded="false">
      <div class="panel-body">- Community Driven Project<br>
- 100% Safe and Unruggable (10 Years Locked LP)<br>
- Auto-Locking Liquidity For An Ever-Increasing Price Floor<br>
- Deflationary Tokenomics Protect Investors Over Time<br>
- Ownership Renounce After Launch<br>
- Earn Passive Income By Holding $TUMMY</div>
    </div>
  </div>
  <div class="panel panel-default wow  fadeIn" data-wow-duration="1000" data-wow-delay="600ms" >
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapse3" aria-expanded="false">What is the future of $TUMMY? <div class="plus_minus"><i class="fa fa-plus"></i><i class="fa fa-minus"></i></div></a>
      </h4>
    </div>
    <div id="collapse3" class="panel-collapse collapse" aria-expanded="false">
      <div class="panel-body">We are planning to launch our own DEX, NFT Platform and Charity Platform in the future (est Q4 2021). We will be integrating a payment processing system that allows holders to pay in our platforms (DEX, NFT, Charity) with Tummy tokens! </div>
    </div>
  </div>
</div>
</div>
<div class="col-sm-6"><img src="img/tummy-coin-faq.png" class="img-responsive" /></div>
</div>
</div>
</div>
</div>
</section>
   <canvas id="banner_canvas" class="transparent_effect"></canvas>
<?php include 'include/footer.php';?>
</body></html>
